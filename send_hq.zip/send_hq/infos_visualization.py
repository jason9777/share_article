# !/usr/bin/python3
# -*- coding: utf-8 -*-


import dash
from dash import Dash, dcc, html
from dash.dependencies import Input, Output, State
import feffery_antd_components as fac
from pymongo import MongoClient
from views import website, gongzhonghao
import pprint
from selenium import webdriver


test_app = Dash(__name__)
test_app.title = "信息采集数据展示"
test_app.layout = html.Div(
    [
        dcc.Location(id='url'),
        fac.AntdLayout(
            [
                fac.AntdSider(
                    [
                        html.Div(
                            fac.AntdInput(placeholder='输入搜索内容', mode='search'),
                            style={
                                'padding': '5px'
                            }
                        ),
                        html.Div(
                            [
                                fac.AntdMenu(
                                    id='sidebar_options',
                                    menuItems=[
                                        {
                                            'component': 'Item',
                                            'props': {
                                                'key': '公众号',
                                                'title': '公众号',
                                                'icon': 'fc-folder',
                                                'href': '/',
                                            }
                                        },
                                        {
                                            'component': 'Item',
                                            'props': {
                                                'key': '网站',
                                                'title': '网站',
                                                'icon': 'fc-folder',
                                                'href':'/website',
                                            }
                                        },
                                        {
                                            'component': 'Item',
                                            'props': {
                                                'key': '知乎专栏',
                                                'title': '知乎专栏',
                                                'icon': 'fc-folder',
                                                'href': '/zhihu',
                                            }
                                        },
                                        {
                                            'component': 'Item',
                                            'props': {
                                                'key': '今日头条',
                                                'title': '今日头条',
                                                'icon': 'fc-folder',
                                                'href': '/toutiao',
                                            }
                                        },
                                    ],
                                    mode='inline'
                                )
                            ],
                            style={
                                'height': '100%',
                                'overflowY': '100%'
                            }
                        )
                    ],
                    collapsible=True,
                    style={
                        'backgroundColor': 'rgb(240, 242, 245)'
                    }
                ),

                fac.AntdContent(
                    id='data_content',
                    style={
                        'backgroundColor': 'white'
                    }
                )
            ],
            style={
                'height': '600px'
            }
        )
    ],
    id='sider-demo',
    style={
        'height': '600px',
        'border': '1px solid rgb(241, 241, 241)'
    }
)




@test_app.callback(
        [Output('data_content', 'children'),
        Output('sidebar_options', 'currentKey')],
        Input('url', 'pathname'),
        prevent_initial_call=True,
        suppress_callback_exceptions=True
    )
def render_data_contents(pathname):
    """
    路由回调展示数据
    """
    print('----------------')
    # ctx = dash.callback_context
    # pprint.pprint(ctx)
    pprint.pprint(pathname)
    if pathname == '/':
        return gongzhonghao.show_contents, pathname
    elif pathname == '/website':
        return website.show_contents, pathname
    # elif pathname == '/zhihu':
    #     return 
    # elif pathname == '/toutiao':
    #     return 
    else:
        return fac.AntdResult(status='404', title='您访问的页面不存在！'), pathname



#构造前端返回数据
@test_app.callback(
    Output('wechat_data', 'data'),
    Input('url', 'pathname'),
    )
def get_data(p):
    print('!!!!!!!!!!:', p)
    client = MongoClient(host='localhost', port=27017)
    find_db = client['wechat_extract']
    res = find_db['test_db_wechat_article_infos']
    res_list = res.find()
    data_list = []
    # temp_dict = {}
    key = 0
    for r in res_list:
        temp_dict = {}
        title = r['article_title']
        link = r['url_link']
        temp_dict['key'] = key
        temp_dict['发布时间'] = r['create_time']
        temp_dict['文章标题'] = {'href': link, 'content': title}
        temp_dict['来源'] = r['name']
        temp_dict['更新时间'] = r['update_time']
        data_list.append(temp_dict)
        key += 1
    pprint.pprint(data_list)
    return data_list



if __name__ == "__main__":
    test_app.run_server(host='10.81.221.147', port=8050, debug=True)