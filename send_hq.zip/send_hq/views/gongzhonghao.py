# !/usr/bin/python3
# -*- coding: utf-8 -*-



from dash import Dash, dcc, html
from dash.dependencies import Input, Output, State
import feffery_antd_components as fac
from pymongo import MongoClient
from infos_visualization import test_app


show_contents = html.Div([
        fac.AntdTable(
            id='wechat_data',
            columns=[
                {
                    'title': '发布时间', #创建时间
                    'dataIndex': '发布时间',
                    # 'renderOptions': {
                    #     'renderType': 'link',
                    #     'renderLinkText': '点击跳转'
                    # }
                },
                {
                    'title': '文章标题',
                    'dataIndex': '文章标题',
                    'renderOptions': {
                        'renderType': 'link',
                        'renderLinkText': '点击跳转'   #超链接显示内容
                    }
                },
                {
                    'title': '来源',
                    'dataIndex': '来源',
                },
                {
                    'title': '更新时间', #update时间
                    'dataIndex': '更新时间'
                }
            ],
            bordered=True,
            style={
                'width': '100%',
                'height': '100%',

            }
        ),
    ],
    id='test',
        style={
            'display': 'flex',
            'height': '100%',
            'justifyContent': 'center',
            'alignItems': 'center'
        }
    )




#构造前端返回数据
@test_app.callback(
    Output('wechat_data', 'data'),
    Input('sidebar_options', 'href'),
     # Input('wechat_data', 'recentlyChangedRow'),
     # Input('wechat_data', 'sorter'),
     # Input('wechat_data', 'filter'),
     # Input('wechat_data', 'pagination'),
    )
def get_data(href):
    print('!!!!!!!!!!:', pathname)
    client = MongoClient(host='localhost', port=27017)
    find_db = client['wechat_extract']
    res = find_db['test_db_wechat_article_infos']
    res_list = res.find()
    data_list = []
    # temp_dict = {}
    key = 0
    for r in res_list:
        temp_dict = {}
        title = r['article_title']
        link = r['url_link']
        temp_dict['key'] = key
        temp_dict['发布时间'] = r['create_time']
        temp_dict['文章标题'] = {'href': link, 'content': title}
        temp_dict['来源'] = r['name']
        temp_dict['更新时间'] = r['update_time']
        data_list.append(temp_dict)
        key += 1
    pprint.pprint(data_list)
    return data_list