# !/usr/bin/python3
# -*- coding: utf-8 -*-



from dash import Dash, dcc, html
from dash.dependencies import Input, Output, State
import feffery_antd_components as fac
from pymongo import MongoClient


show_contents = html.Div(
	[
	fac.AntdText(
		'敬请期待~~~',
		strong=True,)
	]
	)